import React from 'react';
export default function AssignmentCard({a}){ return (<div><h4 style={{margin:'0 0 6px 0'}}>{a.title}</h4><div className='small-muted'>{a.description}</div></div>) }